import { View, Text } from 'react-native'
import React from 'react'

const Footer = () => {
  return (
    <View>
      <Text>Footer</Text>
    </View>
  )
}

export default Footer