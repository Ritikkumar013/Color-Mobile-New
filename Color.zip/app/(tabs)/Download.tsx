import { View, Text } from "react-native";
import { Link } from "expo-router";

const Download = () => {
  return (
    <View className="p-4 flex items-center">
      <Text className="p-7 text-white text-2xl mt-10 bg-green-600">Download Now</Text>
    </View>
  );
};

export default Download;
